/*
このファイルには Query, Unload を使ってデータをエクスポートする前に
実行したい無名 PL/SQL ブロックを記述する事ができます。
使用するには環境変数 PRE_REP_EXEC_PLS の値にこのファイルの名前 PreRepPls.sql を
与えて環境変数 INPUT の指し示すディレクトリへ配置してください。
典型的な応用例では次のようなものがあります。
(1). Oracle Virtual Private Database 用の DBMS_SESSION.SET_CONTEXT 実行
(2). v$logmnr_contents 表問合せ前の DBMS_LOGMNR パッケージ実行
※このファイルの末尾にスラッシュ記号は含めないで下さい
*/
begin 
	null;
end;

