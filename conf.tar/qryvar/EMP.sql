/* サンプルスクリプト（２）*/
/* 機能：バインド変数で与えられた条件を満たす行を戻す */
select *
from emp
where job = :b_job
and sal > :b_sal
and hiredate > to_date(:b_hiredate, 'yyyy-mm-dd');
