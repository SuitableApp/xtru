/* サンプルスクリプト（１）*/
/* 機能：部門毎の平均給与を戻す */
/* (1). 式の結果を戻す列には３０文字以内で別名を与える */
/* (2). 環境変数 SRC_USER へ指定したユーザの所有する
 * オブジェクトではない場合、スキーマ修飾子を与える
 */
select d.dname
, round(avg(e.sal), 3) as avg       ---------- (1)
from scott.emp e                    ---------- (2)
,    scott.dept d
where d.deptno = e.deptno
group by d.dname
;

