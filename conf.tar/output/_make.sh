#!/bin/sh

ps -ef -u $USER -f
ls -l ..
uname -a

