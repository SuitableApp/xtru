select * from DEPT;
