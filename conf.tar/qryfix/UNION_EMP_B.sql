/*
 * 集合化クエリの例 (2)
 */
select e.empno, e.ename, e.sal, d.dname, d.loc 
	from emp e, dept d 
	where e.deptno = d.deptno and d.dname = 'ACCOUNTING';
select e.empno, e.ename, e.sal, d.dname, d.loc 
	from emp e, dept d 
	where e.deptno = d.deptno and d.dname = 'RESEARCH';
select e.empno, e.ename, e.sal, d.dname, d.loc 
	from emp e, dept d 
	where e.deptno = d.deptno and d.dname = 'SALES';
select e.empno, e.ename, e.sal, d.dname, d.loc 
	from emp e, dept d 
	where e.deptno = d.deptno and d.dname = 'OPERATIONS';

