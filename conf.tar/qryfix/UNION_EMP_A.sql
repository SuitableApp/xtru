/*
 * 集合化クエリの例
 * 選択列リストが等しく、述語が異なる複数のクエリ集合の結果を
 * 一つのデータファイルへ格納することが出来ます。
 * 各クエリは指定された並列度を上限に並列処理されます。
 * 各クエリは半角コロン文字でセパレートされていなければなりません。
 */
select * from emp where job = 'ANALYST' and hiredate > to_date(:b_hiredate, 'yyyy-mm-dd');
select * from emp where job = 'CLERK' and hiredate > to_date(:b_hiredate, 'yyyy-mm-dd');
select * from emp where job = 'MANAGER' and hiredate > to_date(:b_hiredate, 'yyyy-mm-dd');
select * from emp where job = 'PRESIDENT' and hiredate > to_date(:b_hiredate, 'yyyy-mm-dd');
select * from emp where job = 'SALESMAN' and hiredate > to_date(:b_hiredate, 'yyyy-mm-dd');

